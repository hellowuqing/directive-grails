package hand.directive

class Directive {
    String   id
    String   directive_loc
    String   directive_explain
    String   directive_version
    String   like_num
    String   createdBy
    String   updatedBy
    Date     dateCreated
    Date     lastUpdated
    Integer  version

    static constraints = {
        createdBy   nullable: true
        updatedBy   nullable: true
        dateCreated nullable: true
        lastUpdated nullable: true
    }

    static mapping = {
        table 'directive'

        id                 generator: 'uuid.hex',column:'id'
        directive_loc      column: 'directive_loc'
        directive_explain  column: 'directive_explain'
        directive_version  column: 'directive_version'
        like_num           column: 'like_num'
        dateCreated        column:  'create_date'
        createdBy          column:  'created_by'
        updatedBy          column:  'updated_by'
        lastUpdated        column:  'update_date'
        version            column:  'version'
    }

    def globalParamsService
    def beforeInsert() {
        createdBy=globalParamsService.getUser()
        updatedBy=globalParamsService.getUser()
        Date time = new Date()
        dateCreated = time
        lastUpdated = time
    }

    def beforeUpdate() {
        updatedBy=globalParamsService.getUser()
        lastUpdated = new Date()
    }
}
